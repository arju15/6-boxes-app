import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ImageComponent } from './image-component/image.component'
import { DragDropDirective } from './shared/directives/drag-drop.directives';
@NgModule({
  declarations: [
    AppComponent,
    ImageComponent,
    DragDropDirective
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
